package com.swetlox_app.swetlox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwetloxApplicationTests {

	@Test
	void contextLoads() {
	}

}
