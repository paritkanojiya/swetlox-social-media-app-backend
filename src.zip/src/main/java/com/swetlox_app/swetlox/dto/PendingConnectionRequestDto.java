package com.swetlox_app.swetlox.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PendingConnectionRequestDto {
    private String id;
    private String senderId;
    private String userName;
    private String fullName;
    private String requestedUserEmail;
    private String profileURL;
}
