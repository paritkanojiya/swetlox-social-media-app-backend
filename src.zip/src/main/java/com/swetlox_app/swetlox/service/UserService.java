package com.swetlox_app.swetlox.service;


import com.cloudinary.Cloudinary;
import com.swetlox_app.swetlox.allenum.UserType;
import com.swetlox_app.swetlox.entity.Role;
import com.swetlox_app.swetlox.entity.User;
import com.swetlox_app.swetlox.exception.customException.UserAlreadyExistEx;
import com.swetlox_app.swetlox.dto.UserDto;
import com.swetlox_app.swetlox.model.ProfileModel;
import com.swetlox_app.swetlox.repository.UserRepo;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepo userRepository;
    private final PasswordEncoder passwordEncoder;
    private final MailService otpService;
    private final JwtService jwtService;
    private final Cloudinary cloudinaryTemplate;
    private final ModelMapper mapper;
    @Lazy
    @Autowired
    private  StoryService storyService;

    @Lazy
    @Autowired
    private  PostService postService;
    @Lazy
    @Autowired
    private UserConnectionService userConnectionService;

    @Scheduled(fixedRate = 60000)
    public void deleteNotVerifyUser(){
        LocalDateTime tenMinutesAgo=LocalDateTime.now().minusMinutes(10);
        List<User> deletedUser = userRepository.findByIsVerifiedFalseAndCreatedAtBefore(tenMinutesAgo);
        userRepository.deleteAll(deletedUser);
    }

    public User getUser(String email){
        return userRepository.findByEmail(email).orElseThrow(()-> new UsernameNotFoundException("provided user email is not found"));
    }
    
    public User saveUser(UserDto userDto) throws UserAlreadyExistEx, MessagingException {
        Optional<User> optionalUser = userRepository.findByEmail(userDto.getEmail());
        if(optionalUser.isEmpty()){
            User user = toEntity(userDto);
            user.setUserType(UserType.EMAIL);
            otpService.sendOtp(user.getEmail());
            return userRepository.save(user);
        }
        User user = optionalUser.get();
        if(Boolean.FALSE.equals(user.getIsVerified())){
            otpService.sendOtp(user.getEmail());
            return user;
        }
        throw new UserAlreadyExistEx(userDto.getEmail()+ " user already present");
    }
    
    public User saveOAuth2User(UserDto userDto){
        User user = toEntity(userDto);
        user.setIsVerified(true);
        return userRepository.save(user);
    }
    
    
    public void changeVerificationStatus(String email){
        User user = getUser(email);
        if(!user.getIsVerified()){
            user.setIsVerified(true);
            updateUser(user);
        }
    }

    private User toEntity(UserDto userDto){
        String encodedPassword=userDto.getPassword()!=null ? passwordEncoder.encode(userDto.getPassword()) : null;
        return User.builder().userName(userDto.getUserName())
                .fullName(userDto.getFullName())
                .email(userDto.getEmail())
                .password(encodedPassword)
                .roleList(List.of(new Role("ROLE_USER")))
                .userType(userDto.getUserType())
                .isVerified(false)
                .profileURL("https://res.cloudinary.com/dkbbhmnk6/image/upload/v1724336510/default_ia7jfs.jpg")
                .build();
    }

    public void updatePassword(User user,String rawNewPassword){
        user.setPassword(passwordEncoder.encode(rawNewPassword));
        userRepository.save(user);
    }

    public void updateUser(User user){
        userRepository.save(user);
    }

    public User getUserById(String id){
        System.out.println(id);
        return userRepository.findById(id).orElseThrow(()->new RuntimeException("user not found"));
    }

    public User getAuthUser(String token){
        String userEmail = jwtService.extractUserNameFromToken(token.substring(7));
        return userRepository.findByEmail(userEmail).orElseThrow(()-> new RuntimeException("User not found"));
    }

    public boolean isUserExist(String email){
        return userRepository.existsByEmail(email);
    }

    public List<Map<String, Object>> searchUser(String q, User authUser) {
        List<Map<String, Object>> users = new ArrayList<>();
        if (q.isEmpty()) {
            return Collections.emptyList();
        } else {
            userRepository.findByUserName(q).forEach(user -> {
                boolean followerContainsUserId = userConnectionService.existsByIdAndFollowerContains(authUser.getId(), user.getId());
                boolean isRequestPending=userConnectionService.isConnectionRequestPending(authUser.getId(),user.getId());
                boolean followingContainsUserId = userConnectionService.existsByIdAndFollowingContains(authUser.getId(), user.getId());
                System.out.println(followingContainsUserId);
                boolean userIsFollowingAuth = userConnectionService.existsByIdAndFollowingContains(user.getId(), authUser.getId());
                Map<String, Object> userMap = Map.of(
                        "userId", user.getId(),
                        "email",user.getEmail(),
                        "userName", user.getUserName(),
                        "follower", followerContainsUserId,
                        "requested",isRequestPending,
                        "following", followingContainsUserId,
                        "userIsFollowingAuth", userIsFollowingAuth,
                        "profileURL",user.getProfileURL()
                );
                users.add(userMap);
            });
        }
        return users;
    }


    public UserDto changeProfileImage(MultipartFile file,User authUser) throws IOException {
        Map uploaded = cloudinaryTemplate.uploader().upload(file.getBytes(), Collections.emptyMap());
        String profileURL=(String)uploaded.get("url");
        authUser.setProfileURL(profileURL);
        User updatedUser = userRepository.save(authUser);
        return mapper.map(updatedUser, UserDto.class);
    }

    public ProfileModel profileData(User authUser){
        List<String> followerList = userConnectionService.getFollowerList(authUser.getId());
        List<String> followingList = userConnectionService.getFollowingList(authUser.getId());
        Integer userPostCount = postService.getUserPostCount(authUser.getId());

        int follower = (followerList != null) ? followerList.size() : 0;
        int following = (followingList != null) ? followingList.size() : 0;

        return ProfileModel.builder().userName(authUser.getUserName())
                .fullName(authUser.getFullName())
                .profileURL(authUser.getProfileURL())
                .follower(follower)
                .following(following)
                .bio(authUser.getBio())
                .postCount(userPostCount)
                .build();
    }

    public List<UserDto> findUserConnection(String authUser){
        return userConnectionService.getFollowerAndFollowing(authUser);
    }

    public long getNumOfUser(){
        return userRepository.count();
    }
    
    public Page<User> getAllUser(Integer pageNum){
        PageRequest pageRequest = PageRequest.of(pageNum, 5);
        return userRepository.findAll(pageRequest);
    }
    
    public void deleteUser(String id){
        User user = getUserById(id);
        userRepository.delete(user);
        postService.deleteAllPostByUserId(id);
        storyService.deleteStoryByUserId(id);
        userConnectionService.deleteUserFromAllConnections(id);
    }
}

