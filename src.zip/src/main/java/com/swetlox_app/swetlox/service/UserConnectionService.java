package com.swetlox_app.swetlox.service;

import com.swetlox_app.swetlox.allenum.ConnectionRequestStatus;
import com.swetlox_app.swetlox.dto.PendingConnectionRequestDto;
import com.swetlox_app.swetlox.dto.UserDto;
import com.swetlox_app.swetlox.entity.ConnectionRequest;
import com.swetlox_app.swetlox.entity.User;
import com.swetlox_app.swetlox.entity.UserConnection;
import com.swetlox_app.swetlox.event.SendConnectionRequestEvent;
import com.swetlox_app.swetlox.repository.ConnectionRequestRepo;
import com.swetlox_app.swetlox.repository.UserConnectionRepo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserConnectionService {

    private final UserConnectionRepo userConnectionRepo;
    private final ConnectionRequestRepo connectionRequestRepo;
    private final ApplicationEventPublisher eventPublisher;
    @Autowired
    private  UserService userService;

    @Async(value = "taskExecutor")
    public void following(String requestedUserId, User authUser){
        User user = userService.getUserById(requestedUserId);
        ConnectionRequest connectionRequest = saveConnectionRequest(requestedUserId, authUser.getId());
        PendingConnectionRequestDto pendingConnectionRequestDto = entityToPendingConnectionRequestDto(connectionRequest);
        eventPublisher.publishEvent(new SendConnectionRequestEvent(this,pendingConnectionRequestDto));
    }

    public List<PendingConnectionRequestDto> getAllPendingConnectionRequest(String authToken){
        User authUser = userService.getAuthUser(authToken);
        return connectionRequestRepo.findByReceiverIdAndStatus(authUser.getId(),ConnectionRequestStatus.PENDING).stream().map(this::entityToPendingConnectionRequestDto).collect(Collectors.toList());
    }

    public boolean isConnectionRequestPending(String senderId,String receiverId){
       return connectionRequestRepo.existsBySenderIdAndReceiverIdAndStatus(senderId,receiverId,ConnectionRequestStatus.PENDING);
    }

    public boolean isAlreadyExistConnectionRequest(String requestId,String authUserId){
        return connectionRequestRepo.findBySenderIdAndReceiverId(authUserId,requestId).isPresent();
    }
    public PendingConnectionRequestDto entityToPendingConnectionRequestDto(ConnectionRequest connectionRequest){
        User user = userService.getUserById(connectionRequest.getSenderId());
        return PendingConnectionRequestDto.builder()
                .id(connectionRequest.getId())
                .requestedUserEmail(user.getEmail())
                .userName(user.getUserName())
                .senderId(user.getId())
                .fullName(user.getFullName())
                .profileURL(user.getProfileURL()).build();
    }

    public ConnectionRequest saveConnectionRequest(String requestId,String authUserId){
        boolean connectionRequestPending = isConnectionRequestPending(requestId, authUserId);
        if(!connectionRequestPending) {
            ConnectionRequest connectionRequest = ConnectionRequest.builder()
                    .senderId(authUserId)
                    .receiverId(requestId)
                    .status(ConnectionRequestStatus.PENDING)
                    .build();
            return connectionRequestRepo.save(connectionRequest);
        }
        throw new RuntimeException("Request already made");
    }

    
    public ConnectionRequest getConnectionRequest(String requestedId,String authUserId){
        return connectionRequestRepo.findBySenderIdAndReceiverId(requestedId,authUserId).orElseThrow(()->new RuntimeException("Not found user connection"));
    }
    
    @Transactional
    public void acceptRequest(User authUser,String requestedUserId){
        System.out.println(requestedUserId);
        ConnectionRequest connectionRequest = getConnectionRequest(requestedUserId, authUser.getId());
        connectionRequest.setStatus(ConnectionRequestStatus.ACCEPTED);
        UserConnection authUserConnection = userConnectionRepo.findByUserId(authUser.getId()).orElseGet(() -> createNewConnection(authUser.getId()));
        UserConnection requestedUserConnection = userConnectionRepo.findByUserId(requestedUserId).orElseGet(() -> createNewConnection(requestedUserId));
        if(!authUserConnection.getFollower().contains(requestedUserId)){
            authUserConnection.getFollower().add(requestedUserId);
        }
        if(!requestedUserConnection.getFollowing().contains(authUser.getId()
        )){
            requestedUserConnection.getFollowing().add(authUser.getId());
        }
        update(connectionRequest);
        userConnectionRepo.saveAll(Arrays.asList(authUserConnection,requestedUserConnection));
    }

    public void update(ConnectionRequest connectionRequest){
        connectionRequestRepo.save(connectionRequest);
    }

    private UserConnection createNewConnection(String authId) {
        UserConnection userConnection=new UserConnection();
        userConnection.setUserId(authId);
        userConnection.setFollowing(new ArrayList<>());
        userConnection.setFollower(new ArrayList<>());
        return userConnection;
    }
    
    public List<String> getFollowerList(String authId){
        Optional<UserConnection> userConnectionOptional = userConnectionRepo.findByUserId(authId);
        if(userConnectionOptional.isPresent()){
            return userConnectionOptional.get().getFollower();
        }
        return Collections.emptyList();
    }


    public List<String> getFollowingList(String authId){
        Optional<UserConnection> userConnectionOptional = userConnectionRepo.findByUserId(authId);
        if(userConnectionOptional.isPresent()){
            return userConnectionOptional.get().getFollowing();
        }
        return Collections.emptyList();
    }

    public boolean existsByIdAndFollowerContains(String authId,String userId){
        return userConnectionRepo.existsByIdAndFollowerContains(authId,userId);
    }
    public boolean existsByIdAndFollowingContains(String authId,String userId){
        return userConnectionRepo.existsByIdAndFollowingContains(authId,userId);
    }
    
    public List<UserDto> getFollowerAndFollowing(String authId){
        Optional<UserConnection> optionalUserConnection = userConnectionRepo.findByUserId(authId);
        List<UserDto> userDtoList=new ArrayList<>();
        if(optionalUserConnection.isPresent()){
            UserConnection userConnection = optionalUserConnection.get();
            Set<String> uniqueId=new HashSet<>();
            userConnection.getFollower().stream().filter(uniqueId::add).map(userService::getUserById).map(this::convertToUserDto).forEach( (userDtoList::add));
            userConnection.getFollowing().stream().filter(uniqueId::add).map(userService::getUserById).map(this::convertToUserDto).forEach( (userDtoList::add));
        }
        return userDtoList;
    }

    private UserDto convertToUserDto(User user){
        return UserDto.builder()
                .userName(user.getUserName())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .profileURL(user.getProfileURL())
                .build();
    }

    public void deleteUserFromAllConnections(String id) {
        List<String> followingList = getFollowingList(id);
        List<String> followerList = getFollowerList(id);
        followerList.stream()
                .map(this::userConnection)
                .forEach(user -> {
                    if (user != null && user.getFollower() != null) {
                        boolean removed = user.getFollower().remove(id);
                        if (removed) {
                            userConnectionRepo.save(user);
                            System.out.println("Removed user " + id + " from follower of " + user.getUserId());
                        }
                    }
                });
        followingList.stream()
                .map(this::userConnection)
                .forEach(user -> {
                    if (user != null && user.getFollowing() != null) {
                        boolean removed = user.getFollowing().remove(id);
                        if (removed) {
                            userConnectionRepo.save(user);
                            System.out.println("Removed user " + id + " from following list of " + user.getUserId());
                        }
                    }
                });
        userConnectionRepo.deleteByUserId(id);
    }


    public UserConnection userConnection(String id){
        return userConnectionRepo.findByUserId(id).get();
    }
}
