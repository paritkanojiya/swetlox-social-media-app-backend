package com.swetlox_app.swetlox.service;

import com.swetlox_app.swetlox.allenum.UserType;
import com.swetlox_app.swetlox.dto.UserDto;
import com.swetlox_app.swetlox.entity.User;
import com.swetlox_app.swetlox.exception.customException.UserAlreadyExistEx;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;


@Service
@RequiredArgsConstructor
@Slf4j
public class OAuth2Service {


    private final UserService userService;
    private final Environment environment;

    public User saveOAut2User(UserDto user) {
        if(user.getEmail()==null) throw new RuntimeException("User email can not be null");
        boolean userExist = userService.isUserExist(user.getEmail());
        if(!userExist) {
            return userService.saveOAuth2User(user);
        }
        User auth2User = userService.getUser(user.getEmail());
        if(auth2User.getUserType().equals(UserType.EMAIL)) throw new RuntimeException("provided email already register");
        if(!auth2User.getUserType().equals(user.getUserType()))  auth2User.setUserType(user.getUserType());
        userService.updateUser(auth2User);
        return auth2User;
    }

    public String oAuth2Login(String oauth2LoginId){
        oauth2LoginId=oauth2LoginId.trim().toUpperCase();
        switch (oauth2LoginId){
            case "GOOGLE"->{
                return getGoogleOauth2LoginURI();
            }
            case "GITHUB"->{
                return getGithubOauth2LoginURI();
            }
            default ->
                throw new RuntimeException("No OAuth2 provider found");
        }
    }


    private String getGoogleOauth2LoginURI(){
        String googleLoginURI = environment.getProperty("oAuth2.google.oauth2-login-uri");
        String clientId = environment.getProperty("oAuth2.google.clientId");
        return googleLoginURI+"?client_id="+clientId+"&redirect_uri=http://localhost:9000/swetlox/v1/auth/login/google&response_type=code&scope=email%20profile";
    }

    private String getGithubOauth2LoginURI(){
        String googleLoginURI = environment.getProperty("oAuth2.github.oauth2-login-uri");
        String clientId = environment.getProperty("oAuth2.github.clientId");
        return googleLoginURI+"?client_id="+clientId;
    }
}
