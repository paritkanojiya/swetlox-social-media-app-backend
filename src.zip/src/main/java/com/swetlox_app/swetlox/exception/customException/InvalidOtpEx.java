package com.swetlox_app.swetlox.exception.customException;

public class InvalidOtpEx extends Throwable {
    public InvalidOtpEx(String string) {
        super(string);
    }
}
