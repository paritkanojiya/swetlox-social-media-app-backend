package com.swetlox_app.swetlox.exception.customException;

public class UserAlreadyExistEx extends Throwable {
        public UserAlreadyExistEx(String string) {
            super(string);
        }
}
