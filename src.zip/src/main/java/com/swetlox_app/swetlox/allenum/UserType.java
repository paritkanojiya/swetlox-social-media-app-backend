package com.swetlox_app.swetlox.allenum;

public enum UserType {
    EMAIL,
    GOOGLE,
    GITHUB
}
