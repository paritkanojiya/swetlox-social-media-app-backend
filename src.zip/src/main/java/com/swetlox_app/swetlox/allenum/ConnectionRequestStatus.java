package com.swetlox_app.swetlox.allenum;

public enum ConnectionRequestStatus {
    ACCEPTED,
    PENDING,
    DECLINED
}
