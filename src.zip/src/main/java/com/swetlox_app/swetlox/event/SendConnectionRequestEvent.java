package com.swetlox_app.swetlox.event;

import com.swetlox_app.swetlox.dto.PendingConnectionRequestDto;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class SendConnectionRequestEvent extends ApplicationEvent {
   private final PendingConnectionRequestDto pendingConnectionRequestDto;

    public SendConnectionRequestEvent(Object source, PendingConnectionRequestDto pendingConnectionRequestDto) {
        super(source);
        this.pendingConnectionRequestDto=pendingConnectionRequestDto;
    }
}
