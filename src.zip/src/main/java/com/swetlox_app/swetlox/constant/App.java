package com.swetlox_app.swetlox.constant;

public class App {
    public static final String BACKENDCONTEXTPATH="http://localhost:9000";
    public static final String FRONTENDCONTEXTPATH="http://localhost:3000";
}
